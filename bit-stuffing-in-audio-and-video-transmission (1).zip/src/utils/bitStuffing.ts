import { StuffingResult, DestuffingResult } from '../types';

/**
 * Validates whether an input string consists strictly of binary characters (0 and 1).
 */
export function validateBinaryString(input: string): { isValid: boolean; cleaned: string; error?: string } {
  // Allow spaces, trim them
  const cleaned = input.replace(/\s+/g, '');
  if (!cleaned) {
    return { isValid: false, cleaned: '', error: 'Input binary stream cannot be empty.' };
  }
  if (!/^[01]+$/.test(cleaned)) {
    return {
      isValid: false,
      cleaned,
      error: 'Invalid input: only binary characters (0 and 1) are allowed. Letters, symbols, and other numbers are invalid.',
    };
  }
  return { isValid: true, cleaned };
}

/**
 * Standard Bit Stuffing Algorithm:
 * Whenever five consecutive 1s ('11111') are encountered in data,
 * a '0' is immediately stuffed (inserted) after them.
 */
export function performBitStuffing(originalBits: string): StuffingResult {
  const validation = validateBinaryString(originalBits);
  if (!validation.isValid) {
    return {
      originalBits,
      stuffedBits: '',
      stuffedIndices: [],
      insertedCount: 0,
      originalLength: originalBits.length,
      stuffedLength: 0,
      overheadPercentage: 0,
      isValid: false,
      errorMessage: validation.error,
      consecutiveOnesPositions: [],
    };
  }

  const bits = validation.cleaned;
  let stuffed = '';
  const stuffedIndices: number[] = [];
  const consecutiveOnesPositions: number[] = [];
  let consecutiveOnes = 0;

  for (let i = 0; i < bits.length; i++) {
    const bit = bits[i];
    stuffed += bit;

    if (bit === '1') {
      consecutiveOnes++;
      if (consecutiveOnes === 5) {
        // Record position in original stream
        consecutiveOnesPositions.push(i);
        // Stuff a '0' immediately after five 1s
        stuffed += '0';
        stuffedIndices.push(stuffed.length - 1); // index of the stuffed '0' in the stuffed string
        consecutiveOnes = 0; // reset sequence counter after stuffing
      }
    } else {
      consecutiveOnes = 0;
    }
  }

  const insertedCount = stuffedIndices.length;
  const overheadPercentage = bits.length > 0 ? (insertedCount / bits.length) * 100 : 0;

  return {
    originalBits: bits,
    stuffedBits: stuffed,
    stuffedIndices,
    insertedCount,
    originalLength: bits.length,
    stuffedLength: stuffed.length,
    overheadPercentage: parseFloat(overheadPercentage.toFixed(2)),
    isValid: true,
    consecutiveOnesPositions,
  };
}

/**
 * Standard Bit Destuffing Algorithm:
 * Scans the stuffed stream. When five consecutive 1s are encountered,
 * the subsequent '0' bit (which was stuffed by the sender) is removed.
 */
export function performBitDestuffing(stuffedBits: string, expectedOriginal?: string): DestuffingResult {
  const validation = validateBinaryString(stuffedBits);
  if (!validation.isValid) {
    return {
      recoveredBits: '',
      removedIndices: [],
      isMatch: false,
      isValid: false,
      errorMessage: validation.error,
    };
  }

  const bits = validation.cleaned;
  let recovered = '';
  const removedIndices: number[] = [];
  let consecutiveOnes = 0;

  for (let i = 0; i < bits.length; i++) {
    const bit = bits[i];

    if (consecutiveOnes === 5) {
      if (bit === '0') {
        // This is the stuffed '0'. Remove it (skip appending)
        removedIndices.push(i);
        consecutiveOnes = 0; // reset
        continue;
      } else {
        // Bit is '1'. If it's 01111110, it's a flag delimiter or an abort code.
        return {
          recoveredBits: recovered,
          removedIndices,
          isMatch: false,
          isValid: false,
          errorMessage: `Destuffing violation at position ${i}: Encountered '1' following 5 consecutive 1s. In properly stuffed data, this bit must be a stuffed '0'.`,
        };
      }
    }

    recovered += bit;
    if (bit === '1') {
      consecutiveOnes++;
    } else {
      consecutiveOnes = 0;
    }
  }

  const isMatch = expectedOriginal !== undefined ? recovered === expectedOriginal : true;

  return {
    recoveredBits: recovered,
    removedIndices,
    isMatch,
    isValid: true,
  };
}

/**
 * Counts occurrences of the standard HDLC/SDLC flag pattern '01111110'
 */
export function countFlagOccurrences(bitstream: string): number {
  const flag = '01111110';
  let count = 0;
  let pos = bitstream.indexOf(flag);
  while (pos !== -1) {
    count++;
    pos = bitstream.indexOf(flag, pos + 1);
  }
  return count;
}

/**
 * Converts an ArrayBuffer slice to a binary bitstring.
 */
export function arrayBufferToBinary(buffer: ArrayBuffer): { binary: string; hexPreview: string[] } {
  const uint8 = new Uint8Array(buffer);
  let binary = '';
  const hexPreview: string[] = [];

  for (let i = 0; i < uint8.length; i++) {
    const byte = uint8[i];
    binary += byte.toString(2).padStart(8, '0');
    hexPreview.push(byte.toString(16).padStart(2, '0').toUpperCase());
  }

  return { binary, hexPreview };
}
