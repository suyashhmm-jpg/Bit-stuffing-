/**
 * Utility to generate lightweight, valid audio and video files directly in the browser
 * for instant testing without needing external files.
 */

/**
 * Creates a valid PCM WAV audio Blob with a short dual-tone sound (440Hz A4 + 554Hz C#5).
 */
export function createSampleWavBlob(durationSeconds: number = 2.0, sampleRate: number = 8000): Blob {
  const numChannels = 1;
  const bytesPerSample = 2; // 16-bit
  const numSamples = Math.floor(sampleRate * durationSeconds);
  const dataSize = numSamples * numChannels * bytesPerSample;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  // RIFF header
  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true); // file size - 8
  writeString(8, 'WAVE');

  // fmt sub-chunk
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  view.setUint16(20, 1, true); // AudioFormat (1 = PCM)
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * numChannels * bytesPerSample, true); // ByteRate
  view.setUint16(32, numChannels * bytesPerSample, true); // BlockAlign
  view.setUint16(34, 16, true); // BitsPerSample

  // data sub-chunk
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  // Generate pleasant chord waveform
  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    // Tone 1: 440 Hz (A4), Tone 2: 554.37 Hz (C#5) with slight envelope
    const envelope = Math.min(1, Math.min(t * 10, (durationSeconds - t) * 5));
    const sample = 0.5 * Math.sin(2 * Math.PI * 440 * t) + 0.3 * Math.sin(2 * Math.PI * 554.37 * t);
    const intSample = Math.max(-32768, Math.min(32767, Math.floor(sample * envelope * 28000)));
    view.setInt16(offset, intSample, true);
    offset += 2;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

/**
 * Creates a valid, short WebM video Blob using an HTML5 Canvas and MediaRecorder.
 */
export async function createSampleVideoBlob(): Promise<Blob> {
  return new Promise((resolve, reject) => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 320;
      canvas.height = 180;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error('Canvas 2D context is not supported.');
      }

      // Check MediaRecorder support
      if (typeof MediaRecorder === 'undefined' || !canvas.captureStream) {
        // Fallback: minimal valid dummy WebM container header
        const dummy = new Uint8Array([
          0x1a, 0x45, 0xdf, 0xa3, 0x9f, 0x42, 0x86, 0x81, 0x01, 0x42, 0xf7, 0x81, 0x01, 0x42, 0xf2, 0x81, 0x04,
          0x42, 0xf3, 0x81, 0x08, 0x42, 0x82, 0x84, 0x77, 0x65, 0x62, 0x6d, 0x42, 0x87, 0x81, 0x02, 0x42, 0x85,
          0x81, 0x02, 0x18, 0x53, 0x80, 0x67,
        ]);
        resolve(new Blob([dummy], { type: 'video/webm' }));
        return;
      }

      const stream = canvas.captureStream(25);
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp8')
        ? 'video/webm;codecs=vp8'
        : 'video/webm';
      const recorder = new MediaRecorder(stream, { mimeType });
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      recorder.onstop = () => {
        resolve(new Blob(chunks, { type: 'video/webm' }));
      };

      recorder.start();

      let frame = 0;
      const totalFrames = 30; // ~1.2 seconds at 25fps

      const draw = () => {
        // Light clean background
        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(0, 0, 320, 180);

        // Header blue banner
        ctx.fillStyle = '#2563eb';
        ctx.fillRect(0, 0, 320, 32);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText('PBL Video Stream Simulation', 10, 20);

        // Moving data packets / visual representation
        const x = (frame * 8) % 300;
        ctx.fillStyle = '#3b82f6';
        ctx.fillRect(x, 60, 40, 25);
        ctx.fillStyle = '#ffffff';
        ctx.font = '10px monospace';
        ctx.fillText('FRAME', x + 3, 76);

        // Test color bars
        const colors = ['#ef4444', '#f59e0b', '#10b981', '#06b6d4', '#6366f1'];
        colors.forEach((c, idx) => {
          ctx.fillStyle = c;
          ctx.fillRect(20 + idx * 56, 110, 48, 20);
        });

        // Frame number
        ctx.fillStyle = '#475569';
        ctx.font = '11px sans-serif';
        ctx.fillText(`Timestamp: ${(frame / 25).toFixed(2)}s | Resolution: 320x180`, 15, 160);

        frame++;
        if (frame <= totalFrames) {
          requestAnimationFrame(draw);
        } else {
          recorder.stop();
        }
      };

      draw();
    } catch (err) {
      console.warn('Failed to record dynamic video:', err);
      // Fallback
      const fallback = new Uint8Array([0x1a, 0x45, 0xdf, 0xa3, 0x01, 0x00, 0x00, 0x00]);
      resolve(new Blob([fallback], { type: 'video/webm' }));
    }
  });
}
