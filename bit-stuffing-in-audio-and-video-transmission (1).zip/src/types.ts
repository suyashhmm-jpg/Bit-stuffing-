export interface StuffingResult {
  originalBits: string;
  stuffedBits: string;
  stuffedIndices: number[]; // 0-based indices in stuffedBits where inserted '0's reside
  insertedCount: number;
  originalLength: number;
  stuffedLength: number;
  overheadPercentage: number;
  isValid: boolean;
  errorMessage?: string;
  consecutiveOnesPositions: number[]; // indices in originalBits where 5-ones trigger occurred
}

export interface DestuffingResult {
  recoveredBits: string;
  removedIndices: number[]; // indices in stuffedBits that were dropped
  isMatch: boolean;
  isValid: boolean;
  errorMessage?: string;
}

export interface MediaProcessResult {
  fileName: string;
  fileSizeBytes: number;
  fileType: string;
  processedBytesCount: number;
  hexPreview: string[];
  stuffing: StuffingResult;
  destuffing: DestuffingResult;
  flagCheck: {
    flagsInOriginal: number;
    flagsInStuffed: number;
  };
}
