import React, { useState, useRef, useEffect } from 'react';
import { performBitStuffing, performBitDestuffing, arrayBufferToBinary } from './utils/bitStuffing';
import { createSampleWavBlob, createSampleVideoBlob } from './utils/mediaGenerators';
import { StuffingResult, DestuffingResult } from './types';
import { Binary, Play, RotateCcw, Upload, FileAudio, Video, Music, CheckCircle2, AlertCircle } from 'lucide-react';

export default function App() {
  // ---------------------------------------------------------
  // Feature 1: Bit Stuffing (Manual Simulator)
  // ---------------------------------------------------------
  const [binaryInput, setBinaryInput] = useState<string>('1111101111110');
  const [manualStuffResult, setManualStuffResult] = useState<StuffingResult | null>(null);
  const [manualDestuffResult, setManualDestuffResult] = useState<DestuffingResult | null>(null);
  const [manualError, setManualError] = useState<string | null>(null);

  const handleStuffBits = () => {
    setManualError(null);
    setManualDestuffResult(null);
    const res = performBitStuffing(binaryInput);
    if (!res.isValid) {
      setManualError(res.errorMessage || 'Invalid binary data. Please enter only 0s and 1s.');
      setManualStuffResult(null);
      return;
    }
    setManualStuffResult(res);
  };

  const handleDestuffBits = () => {
    if (!manualStuffResult) return;
    setManualError(null);
    const destuff = performBitDestuffing(manualStuffResult.stuffedBits, manualStuffResult.originalBits);
    if (!destuff.isValid) {
      setManualError(destuff.errorMessage || 'Destuffing failed.');
      return;
    }
    setManualDestuffResult(destuff);
  };

  // Auto-run on load for immediate display
  useEffect(() => {
    const res = performBitStuffing('1111101111110');
    if (res.isValid) {
      setManualStuffResult(res);
      const destuff = performBitDestuffing(res.stuffedBits, res.originalBits);
      if (destuff.isValid) {
        setManualDestuffResult(destuff);
      }
    }
  }, []);

  // ---------------------------------------------------------
  // Feature 2: Audio
  // ---------------------------------------------------------
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioName, setAudioName] = useState<string>('');
  const [audioOriginalBits, setAudioOriginalBits] = useState<string>('');
  const [audioStuffResult, setAudioStuffResult] = useState<StuffingResult | null>(null);
  const [audioDestuffResult, setAudioDestuffResult] = useState<DestuffingResult | null>(null);
  const [audioError, setAudioError] = useState<string | null>(null);
  const audioInputRef = useRef<HTMLInputElement | null>(null);

  const processAudioFile = (file: File | Blob, name: string) => {
    setAudioError(null);
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(URL.createObjectURL(file));
    setAudioName(name);

    // Read first 32 bytes (256 bits)
    const slice = file.slice(0, 32);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const buffer = e.target?.result as ArrayBuffer;
        if (!buffer || buffer.byteLength === 0) {
          setAudioError('Could not read audio file.');
          return;
        }
        const { binary } = arrayBufferToBinary(buffer);
        setAudioOriginalBits(binary);
        const st = performBitStuffing(binary);
        setAudioStuffResult(st);
        const dst = performBitDestuffing(st.stuffedBits, binary);
        setAudioDestuffResult(dst);
      } catch (err) {
        setAudioError('Failed to process audio bytes.');
      }
    };
    reader.onerror = () => setAudioError('Failed to read file.');
    reader.readAsArrayBuffer(slice);
  };

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processAudioFile(file, file.name);
  };

  const handleLoadSampleAudio = () => {
    try {
      const blob = createSampleWavBlob(2.0, 8000);
      const file = new File([blob], 'sample_audio.wav', { type: 'audio/wav' });
      processAudioFile(file, 'sample_audio.wav (Synthesized Tone)');
    } catch {
      setAudioError('Could not generate sample audio.');
    }
  };

  // Auto-load sample audio on initial render
  useEffect(() => {
    handleLoadSampleAudio();
  }, []);

  // ---------------------------------------------------------
  // Feature 3: Video
  // ---------------------------------------------------------
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('');
  const [videoOriginalBits, setVideoOriginalBits] = useState<string>('');
  const [videoStuffResult, setVideoStuffResult] = useState<StuffingResult | null>(null);
  const [videoDestuffResult, setVideoDestuffResult] = useState<DestuffingResult | null>(null);
  const [videoError, setVideoError] = useState<string | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);

  const processVideoFile = (file: File | Blob, name: string) => {
    setVideoError(null);
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setVideoUrl(URL.createObjectURL(file));
    setVideoName(name);

    // Read first 32 bytes (256 bits)
    const slice = file.slice(0, 32);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const buffer = e.target?.result as ArrayBuffer;
        if (!buffer || buffer.byteLength === 0) {
          setVideoError('Could not read video file.');
          return;
        }
        const { binary } = arrayBufferToBinary(buffer);
        setVideoOriginalBits(binary);
        const st = performBitStuffing(binary);
        setVideoStuffResult(st);
        const dst = performBitDestuffing(st.stuffedBits, binary);
        setVideoDestuffResult(dst);
      } catch (err) {
        setVideoError('Failed to process video bytes.');
      }
    };
    reader.onerror = () => setVideoError('Failed to read file.');
    reader.readAsArrayBuffer(slice);
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processVideoFile(file, file.name);
  };

  const handleLoadSampleVideo = async () => {
    try {
      const blob = await createSampleVideoBlob();
      const file = new File([blob], 'sample_video.webm', { type: 'video/webm' });
      processVideoFile(file, 'sample_video.webm (Test Pattern)');
    } catch {
      setVideoError('Could not generate sample video.');
    }
  };

  // Auto-load sample video on initial render
  useEffect(() => {
    handleLoadSampleVideo();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans p-4 sm:p-6">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header Banner */}
        <header className="bg-white border-2 border-blue-600 rounded-lg p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <div>
              <div className="text-xs uppercase font-bold tracking-wider text-blue-600">
                College PBL Project &bull; Data Communication
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
                Application of Bit Stuffing Using Audio and Video
              </h1>
            </div>
            <div className="text-xs bg-blue-50 border border-blue-200 text-blue-800 px-3 py-1.5 rounded self-start sm:self-auto font-medium">
              Rule: Insert <strong className="font-mono">0</strong> after five consecutive <strong className="font-mono">11111</strong>
            </div>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-2">
            This application demonstrates bit stuffing on manual binary data, an audio file, and a video file directly in your browser.
          </p>
        </header>

        {/* -------------------------------------------------- */}
        {/* Feature 1: Bit Stuffing */}
        {/* -------------------------------------------------- */}
        <section className="bg-white border border-slate-300 rounded-lg p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
            <div className="w-7 h-7 rounded bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
              1
            </div>
            <h2 className="text-lg font-bold text-slate-900">
              Bit Stuffing Simulator
            </h2>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Enter Binary Data (0s and 1s):
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={binaryInput}
                onChange={(e) => {
                  setBinaryInput(e.target.value);
                  setManualError(null);
                }}
                placeholder="e.g. 1111101111110"
                className="grow px-3 py-2 border border-slate-300 rounded font-mono text-sm tracking-wider focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleStuffBits}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded shadow-xs cursor-pointer"
                >
                  Stuff Bits
                </button>
                <button
                  type="button"
                  onClick={handleDestuffBits}
                  disabled={!manualStuffResult}
                  className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded shadow-xs cursor-pointer ${
                    manualStuffResult
                      ? 'bg-slate-800 hover:bg-slate-900 text-white'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  Destuff Bits
                </button>
              </div>
            </div>
            {manualError && (
              <div className="mt-2 text-xs text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{manualError}</span>
              </div>
            )}
          </div>

          {/* Results for Feature 1 */}
          {manualStuffResult && (
            <div className="space-y-3 pt-2">
              {/* Original Data */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="flex justify-between items-center text-xs text-slate-600 font-semibold mb-1">
                  <span>Original Binary Data:</span>
                  <span className="font-mono">{manualStuffResult.originalLength} bits</span>
                </div>
                <div className="font-mono text-xs sm:text-sm text-slate-800 break-all bg-white p-2 rounded border border-slate-200">
                  {manualStuffResult.originalBits}
                </div>
              </div>

              {/* Stuffed Data */}
              <div className="p-3 bg-blue-50 border border-blue-200 rounded">
                <div className="flex justify-between items-center text-xs text-blue-900 font-semibold mb-1">
                  <span>
                    Stuffed Binary Data (Inserted 0s Highlighted):
                  </span>
                  <span className="font-mono">
                    {manualStuffResult.stuffedLength} bits (+{manualStuffResult.insertedCount} inserted)
                  </span>
                </div>
                <div className="font-mono text-xs sm:text-sm break-all bg-white p-2 rounded border border-blue-200 flex flex-wrap gap-y-0.5">
                  {Array.from(manualStuffResult.stuffedBits).map((bit, idx) => {
                    const isStuffed = manualStuffResult.stuffedIndices.includes(idx);
                    if (isStuffed) {
                      return (
                        <span
                          key={idx}
                          className="bg-blue-600 text-white font-bold px-1 rounded mx-0.5"
                          title="Stuffed 0 inserted after five 1s"
                        >
                          {bit}
                        </span>
                      );
                    }
                    return <span key={idx} className="text-slate-800">{bit}</span>;
                  })}
                </div>
              </div>

              {/* Recovered Data */}
              {manualDestuffResult && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded">
                  <div className="flex justify-between items-center text-xs text-emerald-900 font-semibold mb-1">
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Recovered Binary Data (After Destuffing):</span>
                    </span>
                    <span className="font-mono">{manualDestuffResult.recoveredBits.length} bits</span>
                  </div>
                  <div className="font-mono text-xs sm:text-sm text-slate-800 break-all bg-white p-2 rounded border border-emerald-200">
                    {manualDestuffResult.recoveredBits}
                  </div>
                  <div className="mt-2 text-xs font-semibold text-emerald-800">
                    Original Data Recovered: {manualDestuffResult.isMatch ? 'YES (100% Match)' : 'NO'}
                  </div>
                </div>
              )}
            </div>
          )}
        </section>

        {/* -------------------------------------------------- */}
        {/* Feature 2: Audio */}
        {/* -------------------------------------------------- */}
        <section className="bg-white border border-slate-300 rounded-lg p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
            <div className="w-7 h-7 rounded bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
              2
            </div>
            <h2 className="text-lg font-bold text-slate-900">
              Audio Demonstration
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <input
              ref={audioInputRef}
              type="file"
              accept="audio/*,.wav,.mp3,.ogg"
              onChange={handleAudioUpload}
              className="hidden"
              id="audio-upload-input"
            />
            <label
              htmlFor="audio-upload-input"
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded cursor-pointer shadow-xs"
            >
              <Upload className="w-4 h-4" />
              <span>Upload Audio File</span>
            </label>

            <button
              type="button"
              onClick={handleLoadSampleAudio}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold rounded border border-slate-300 cursor-pointer"
            >
              <FileAudio className="w-4 h-4 text-blue-600" />
              <span>Use Sample Audio</span>
            </button>

            {audioName && (
              <span className="text-xs text-slate-600 font-mono">
                Loaded: {audioName}
              </span>
            )}
          </div>

          {audioError && (
            <div className="text-xs text-red-600 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{audioError}</span>
            </div>
          )}

          {/* Audio Player */}
          {audioUrl && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded">
              <div className="text-xs font-semibold text-slate-600 mb-1.5">
                Play Audio:
              </div>
              <audio src={audioUrl} controls className="w-full h-9" />
            </div>
          )}

          {/* Audio Binary Data & Stuffing */}
          {audioStuffResult && (
            <div className="space-y-3 pt-1">
              {/* Original Binary Data */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="flex justify-between items-center text-xs text-slate-600 font-semibold mb-1">
                  <span>Audio Binary Data (First 32 Bytes):</span>
                  <span className="font-mono">{audioStuffResult.originalLength} bits</span>
                </div>
                <div className="font-mono text-xs text-slate-800 break-all bg-white p-2 rounded border border-slate-200 max-h-28 overflow-y-auto">
                  {audioStuffResult.originalBits}
                </div>
              </div>

              {/* Stuffed Binary Data */}
              <div className="p-3 bg-blue-50 border border-blue-200 rounded">
                <div className="flex justify-between items-center text-xs text-blue-900 font-semibold mb-1">
                  <span>Stuffed Audio Binary Data:</span>
                  <span className="font-mono">
                    {audioStuffResult.stuffedLength} bits (+{audioStuffResult.insertedCount} inserted 0s)
                  </span>
                </div>
                <div className="font-mono text-xs break-all bg-white p-2 rounded border border-blue-200 max-h-28 overflow-y-auto">
                  {Array.from(audioStuffResult.stuffedBits).map((bit, idx) => {
                    const isStuffed = audioStuffResult.stuffedIndices.includes(idx);
                    if (isStuffed) {
                      return (
                        <span key={idx} className="bg-blue-600 text-white font-bold px-0.5 rounded mx-0.5">
                          {bit}
                        </span>
                      );
                    }
                    return <span key={idx} className="text-slate-800">{bit}</span>;
                  })}
                </div>
              </div>

              {/* Recovery Status */}
              {audioDestuffResult && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded text-xs font-semibold text-emerald-800 flex items-center justify-between">
                  <span>Original Audio Data Recovered After Destuffing:</span>
                  <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded">
                    {audioDestuffResult.isMatch ? 'YES (100% Match)' : 'NO'}
                  </span>
                </div>
              )}
            </div>
          )}
        </section>

        {/* -------------------------------------------------- */}
        {/* Feature 3: Video */}
        {/* -------------------------------------------------- */}
        <section className="bg-white border border-slate-300 rounded-lg p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
            <div className="w-7 h-7 rounded bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
              3
            </div>
            <h2 className="text-lg font-bold text-slate-900">
              Video Demonstration
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <input
              ref={videoInputRef}
              type="file"
              accept="video/*,.mp4,.webm"
              onChange={handleVideoUpload}
              className="hidden"
              id="video-upload-input"
            />
            <label
              htmlFor="video-upload-input"
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded cursor-pointer shadow-xs"
            >
              <Upload className="w-4 h-4" />
              <span>Upload Video File</span>
            </label>

            <button
              type="button"
              onClick={handleLoadSampleVideo}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold rounded border border-slate-300 cursor-pointer"
            >
              <Video className="w-4 h-4 text-blue-600" />
              <span>Use Sample Video</span>
            </button>

            {videoName && (
              <span className="text-xs text-slate-600 font-mono">
                Loaded: {videoName}
              </span>
            )}
          </div>

          {videoError && (
            <div className="text-xs text-red-600 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{videoError}</span>
            </div>
          )}

          {/* Video Player */}
          {videoUrl && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded">
              <div className="text-xs font-semibold text-slate-600 mb-1.5">
                Play Video:
              </div>
              <div className="max-w-md mx-auto bg-black rounded overflow-hidden">
                <video src={videoUrl} controls playsInline className="w-full aspect-video" />
              </div>
            </div>
          )}

          {/* Video Binary Data & Stuffing */}
          {videoStuffResult && (
            <div className="space-y-3 pt-1">
              {/* Original Binary Data */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="flex justify-between items-center text-xs text-slate-600 font-semibold mb-1">
                  <span>Video Binary Data (First 32 Bytes):</span>
                  <span className="font-mono">{videoStuffResult.originalLength} bits</span>
                </div>
                <div className="font-mono text-xs text-slate-800 break-all bg-white p-2 rounded border border-slate-200 max-h-28 overflow-y-auto">
                  {videoStuffResult.originalBits}
                </div>
              </div>

              {/* Stuffed Binary Data */}
              <div className="p-3 bg-blue-50 border border-blue-200 rounded">
                <div className="flex justify-between items-center text-xs text-blue-900 font-semibold mb-1">
                  <span>Stuffed Video Binary Data:</span>
                  <span className="font-mono">
                    {videoStuffResult.stuffedLength} bits (+{videoStuffResult.insertedCount} inserted 0s)
                  </span>
                </div>
                <div className="font-mono text-xs break-all bg-white p-2 rounded border border-blue-200 max-h-28 overflow-y-auto">
                  {Array.from(videoStuffResult.stuffedBits).map((bit, idx) => {
                    const isStuffed = videoStuffResult.stuffedIndices.includes(idx);
                    if (isStuffed) {
                      return (
                        <span key={idx} className="bg-blue-600 text-white font-bold px-0.5 rounded mx-0.5">
                          {bit}
                        </span>
                      );
                    }
                    return <span key={idx} className="text-slate-800">{bit}</span>;
                  })}
                </div>
              </div>

              {/* Recovery Status */}
              {videoDestuffResult && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded text-xs font-semibold text-emerald-800 flex items-center justify-between">
                  <span>Original Video Data Recovered After Destuffing:</span>
                  <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded">
                    {videoDestuffResult.isMatch ? 'YES (100% Match)' : 'NO'}
                  </span>
                </div>
              )}
            </div>
          )}
        </section>

        {/* Footer */}
        <footer className="text-center text-xs text-slate-500 pt-2 pb-6">
          First-Year Engineering PBL Project &bull; Application of Bit Stuffing Using Audio and Video
        </footer>

      </div>
    </div>
  );
}
