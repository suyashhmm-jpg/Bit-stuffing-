import React, { useState, useRef } from 'react';
import { performBitStuffing, performBitDestuffing, arrayBufferToBinary, countFlagOccurrences } from '../utils/bitStuffing';
import { createSampleWavBlob } from '../utils/mediaGenerators';
import { MediaProcessResult } from '../types';
import { Music, Upload, Play, Pause, CheckCircle2, AlertCircle, Info, RefreshCw, FileAudio } from 'lucide-react';

interface AudioDemoProps {
  onExportResult?: (result: MediaProcessResult) => void;
}

export const AudioDemo: React.FC<AudioDemoProps> = ({ onExportResult }) => {
  const [selectedFile, setSelectedFile] = useState<File | Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [byteLimit, setByteLimit] = useState<number>(64); // 64 bytes = 512 bits, very clean to display
  const [processResult, setProcessResult] = useState<MediaProcessResult | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Auto-load sample audio on mount for instant demonstration
  React.useEffect(() => {
    try {
      const blob = createSampleWavBlob(2.0, 8000);
      const file = new File([blob], 'sample_pbl_audio.wav', { type: 'audio/wav' });
      processAudioFile(file, 'Sample Audio (Synthesized Dual-Tone 440Hz/554Hz)');
    } catch (err) {
      // ignore
    }
  }, []);

  // Load sample audio (PCM WAV)
  const handleLoadSample = () => {
    try {
      const blob = createSampleWavBlob(2.0, 8000);
      const file = new File([blob], 'sample_pbl_audio.wav', { type: 'audio/wav' });
      processAudioFile(file, 'Sample Audio (Synthesized Dual-Tone 440Hz/554Hz)');
    } catch (err) {
      setErrorMsg('Failed to synthesize sample audio in browser.');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|ogg|aac|m4a|flac)$/i)) {
      setErrorMsg('Please select a valid audio file (.wav, .mp3, .ogg, .aac, .m4a).');
      return;
    }

    processAudioFile(file, file.name);
  };

  const processAudioFile = (file: File | Blob, displayName: string) => {
    setErrorMsg(null);
    setIsProcessing(true);

    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }

    const url = URL.createObjectURL(file);
    setAudioUrl(url);
    setSelectedFile(file);
    setIsPlaying(false);

    // Read only the requested manageable slice of the file (e.g. first 32, 64, or 256 bytes)
    const slice = file.slice(0, byteLimit);
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        if (!buffer || buffer.byteLength === 0) {
          setErrorMsg('Audio file is empty or could not be read.');
          setIsProcessing(false);
          return;
        }

        const { binary, hexPreview } = arrayBufferToBinary(buffer);
        const stuffing = performBitStuffing(binary);
        const destuffing = performBitDestuffing(stuffing.stuffedBits, binary);

        const flagsInOriginal = countFlagOccurrences(binary);
        const flagsInStuffed = countFlagOccurrences(stuffing.stuffedBits);

        const result: MediaProcessResult = {
          fileName: displayName,
          fileSizeBytes: file.size,
          fileType: file.type || 'audio/unknown',
          processedBytesCount: buffer.byteLength,
          hexPreview,
          stuffing,
          destuffing,
          flagCheck: {
            flagsInOriginal,
            flagsInStuffed,
          },
        };

        setProcessResult(result);
        if (onExportResult) {
          onExportResult(result);
        }
      } catch (err) {
        setErrorMsg('Error processing audio binary data.');
      } finally {
        setIsProcessing(false);
      }
    };

    reader.onerror = () => {
      setErrorMsg('Browser failed to read file data.');
      setIsProcessing(false);
    };

    reader.readAsArrayBuffer(slice);
  };

  const togglePlayback = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((e) => {
          console.warn('Playback error:', e);
          setIsPlaying(false);
        });
    }
  };

  const handleAudioEnded = () => {
    setIsPlaying(false);
  };

  const reprocessWithLimit = (newLimit: number) => {
    setByteLimit(newLimit);
    if (selectedFile) {
      processAudioFile(selectedFile, processResult?.fileName || 'Audio');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info Box */}
      <div className="bg-white rounded-lg border border-blue-200 p-5 shadow-xs">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg shrink-0">
              <Music className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-800">
                2. Audio Demonstration
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Upload an audio file or listen to the synthesized sample. The browser converts a slice of audio bytes into binary data, applies bit stuffing (inserting 0 after every five consecutive 1s), and performs bit destuffing.
              </p>
            </div>
          </div>
        </div>

        {/* Mandatory Educational Disclaimer */}
        <div className="mt-4 p-3 bg-blue-50/70 border border-blue-200 rounded-md text-xs text-blue-900 flex items-start gap-2">
          <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <p>
            <strong>PBL Note:</strong> This application demonstrates bit stuffing on the raw binary representation of an audio file as would occur at the Data Link Layer (OSI Layer 2). It does not perform actual physical RF or network transmission. The browser plays the original decoded audio locally.
          </p>
        </div>

        {/* Upload & Sample Audio Controls */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                Option A: Upload Audio File
              </div>
              <p className="text-xs text-slate-500 mb-3">
                Upload your own .mp3, .wav, or .ogg audio file.
              </p>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*,.wav,.mp3,.ogg,.m4a"
              onChange={handleFileUpload}
              className="hidden"
              id="audio-file-input"
            />
            <label
              htmlFor="audio-file-input"
              className="inline-flex items-center justify-center gap-2 px-3 py-2 bg-white border border-slate-300 hover:border-blue-400 text-slate-700 hover:text-blue-700 rounded-md text-xs font-semibold shadow-xs cursor-pointer transition-colors"
            >
              <Upload className="w-4 h-4" />
              <span>Choose Audio File</span>
            </label>
          </div>

          <div className="p-4 bg-blue-50/50 border border-blue-200 rounded-lg flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-blue-900 uppercase tracking-wide mb-1">
                Option B: Quick Sample Audio
              </div>
              <p className="text-xs text-slate-500 mb-3">
                Synthesize a clean dual-tone WAV audio file right inside the browser.
              </p>
            </div>

            <button
              onClick={handleLoadSample}
              className="inline-flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-semibold shadow-xs cursor-pointer transition-colors"
            >
              <FileAudio className="w-4 h-4" />
              <span>Load Synthesized Sample Audio</span>
            </button>
          </div>
        </div>

        {/* Chunk Limit Selector */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 text-xs">
          <span className="text-slate-600 font-medium">
            Manageable slice size to convert and bit-stuff (first N bytes):
          </span>
          <div className="flex items-center gap-1.5">
            {[32, 64, 128, 256].map((size) => (
              <button
                key={size}
                type="button"
                onClick={() => reprocessWithLimit(size)}
                className={`px-2.5 py-1 rounded border text-xs font-mono font-medium transition-colors ${
                  byteLimit === size
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                {size} bytes ({size * 8} bits)
              </button>
            ))}
          </div>
        </div>

        {errorMsg && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Audio Playback & Processed Results */}
      {selectedFile && audioUrl && processResult && (
        <div className="space-y-5">
          {/* Audio Player Card */}
          <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 shrink-0">
                  <FileAudio className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-800">{processResult.fileName}</div>
                  <div className="text-xs text-slate-500">
                    Total File Size: {(processResult.fileSizeBytes / 1024).toFixed(1)} KB &bull; Processed Slice: {processResult.processedBytesCount} bytes ({processResult.stuffing.originalLength} bits)
                  </div>
                </div>
              </div>

              {/* Play / Pause Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={togglePlayback}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-semibold shadow-xs cursor-pointer transition-colors"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isPlaying ? 'Pause Audio' : 'Play Original Audio'}</span>
                </button>
              </div>
            </div>

            {/* Hidden native audio element */}
            <audio
              ref={audioRef}
              src={audioUrl}
              onEnded={handleAudioEnded}
              onPause={() => setIsPlaying(false)}
              onPlay={() => setIsPlaying(true)}
              className="w-full mt-3 h-8"
              controls
            />
          </div>

          {/* Results Display */}
          <div className="bg-white rounded-lg border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
                Audio Bitstream Analysis &amp; Stuffing
              </h3>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Original Recovered: 100% Match
              </span>
            </div>

            {/* Hex preview */}
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <div className="text-xs font-semibold text-slate-600 mb-1">
                Audio Raw Byte Stream (Hexadecimal Preview - first {processResult.hexPreview.length} bytes):
              </div>
              <div className="font-mono text-xs text-slate-700 break-all tracking-wider">
                {processResult.hexPreview.join(' ')}
              </div>
            </div>

            {/* Original vs Stuffed bitstream summary */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Original Bits */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-700 mb-1.5">
                  <span>Original Audio Bitstream</span>
                  <span className="font-mono text-slate-600">{processResult.stuffing.originalLength} bits</span>
                </div>
                <div className="font-mono text-xs text-slate-800 break-all bg-white p-2.5 rounded border border-slate-200 max-h-40 overflow-y-auto leading-relaxed">
                  {processResult.stuffing.originalBits}
                </div>
              </div>

              {/* Stuffed Bits */}
              <div className="p-3 bg-blue-50/50 border border-blue-200 rounded-md">
                <div className="flex justify-between items-center text-xs font-semibold text-blue-900 mb-1.5">
                  <span className="flex items-center gap-1">
                    <span>Stuffed Audio Bitstream</span>
                    <span className="bg-blue-600 text-white text-[10px] px-1 rounded">
                      +{processResult.stuffing.insertedCount} 0s
                    </span>
                  </span>
                  <span className="font-mono text-blue-900">{processResult.stuffing.stuffedLength} bits</span>
                </div>
                <div className="font-mono text-xs tracking-normal break-all bg-white p-2.5 rounded border border-blue-200 max-h-40 overflow-y-auto leading-relaxed">
                  {Array.from(processResult.stuffing.stuffedBits).map((bit, idx) => {
                    const isStuffed = processResult.stuffing.stuffedIndices.includes(idx);
                    if (isStuffed) {
                      return (
                        <span
                          key={idx}
                          className="bg-blue-600 text-white font-bold px-1 rounded mx-0.5 text-[11px]"
                          title={`Stuffed 0 at bit index ${idx}`}
                        >
                          {bit}
                        </span>
                      );
                    }
                    return <span key={idx} className="text-slate-800">{bit}</span>;
                  })}
                </div>
              </div>
            </div>

            {/* Metrics Breakdown Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center pt-2">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="text-xs text-slate-500">Original Bits</div>
                <div className="text-base font-bold text-slate-800 font-mono mt-0.5">
                  {processResult.stuffing.originalLength}
                </div>
              </div>
              <div className="p-3 bg-blue-50/60 border border-blue-200 rounded">
                <div className="text-xs text-blue-700">Stuffed Bits</div>
                <div className="text-base font-bold text-blue-700 font-mono mt-0.5">
                  {processResult.stuffing.stuffedLength}
                </div>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="text-xs text-slate-500">Inserted 0 Bits</div>
                <div className="text-base font-bold text-blue-600 font-mono mt-0.5">
                  +{processResult.stuffing.insertedCount}
                </div>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="text-xs text-slate-500">Overhead (%)</div>
                <div className="text-base font-bold text-slate-800 font-mono mt-0.5">
                  {processResult.stuffing.overheadPercentage}%
                </div>
              </div>
            </div>

            {/* Destuffing verification banner */}
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded text-xs text-emerald-900 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>Destuffing Verification:</strong> Successfully removed all {processResult.stuffing.insertedCount} stuffed 0 bits. 
                  The recovered bitstream is identical to the original audio slice (Verification: 100% Match).
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
