import React from 'react';
import { Binary, GraduationCap, Network, Cpu, Music, Video, BarChart2, BookOpen } from 'lucide-react';

interface HeaderProps {
  onScrollToSection: (sectionId: string) => void;
  activeSection: string;
}

export const Header: React.FC<HeaderProps> = ({ onScrollToSection, activeSection }) => {
  const sections = [
    { id: 'simulator', label: '1. Bit Stuffing Simulator', icon: Cpu },
    { id: 'audio-demo', label: '2. Audio Demonstration', icon: Music },
    { id: 'video-demo', label: '3. Video Demonstration', icon: Video },
    { id: 'results', label: '4. Results & Summary', icon: BarChart2 },
    { id: 'theory', label: 'Learn Theory', icon: BookOpen },
  ];

  return (
    <header className="bg-white border-b border-blue-100 shadow-xs sticky top-0 z-50">
      {/* Top Academic Metadata Banner */}
      <div className="bg-blue-600 text-white px-4 py-3">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 bg-blue-700 rounded-md">
              <GraduationCap className="w-5 h-5 text-blue-100" />
            </span>
            <div>
              <div className="text-xs uppercase tracking-wider font-semibold text-blue-200">
                Project-Based Learning (PBL) &bull; First-Year Engineering
              </div>
              <h1 className="text-base sm:text-lg font-bold tracking-tight">
                Project: Application of Bit Stuffing Using Audio and Video
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs sm:text-sm text-blue-100 bg-blue-700/60 px-3 py-1.5 rounded border border-blue-500/50">
            <div>
              <span className="text-blue-300 font-medium">Subject:</span>{' '}
              <strong className="text-white">Data Communication</strong>
            </div>
            <div className="hidden sm:inline text-blue-400">|</div>
            <div>
              <span className="text-blue-300 font-medium">Topic:</span>{' '}
              <span className="text-white font-medium">Framing &amp; Data Transparency</span>
            </div>
          </div>
        </div>
      </div>

      {/* Single-Page Navigation Anchor Bar */}
      <div className="max-w-6xl mx-auto px-4 py-2">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-slate-700">
            <Binary className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-semibold text-slate-800 hidden sm:inline">
              Single-Page Project Demonstration
            </span>
          </div>

          <div className="text-[11px] text-slate-500 hidden md:flex items-center gap-1.5">
            <Network className="w-3.5 h-3.5 text-blue-500" />
            <span>Rule: Insert <code className="bg-blue-50 text-blue-700 px-1 py-0.5 rounded font-mono font-bold">0</code> after five consecutive <code className="bg-blue-50 text-blue-700 px-1 py-0.5 rounded font-mono font-bold">11111</code></span>
          </div>

          {/* Quick Jump Links */}
          <nav className="flex space-x-1 sm:space-x-1.5 overflow-x-auto scrollbar-none py-1" aria-label="Section Links">
            {sections.map((sec) => {
              const Icon = sec.icon;
              const isActive = activeSection === sec.id;
              return (
                <button
                  key={sec.id}
                  onClick={() => onScrollToSection(sec.id)}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-blue-600 text-white font-semibold shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-blue-50 hover:text-blue-700'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{sec.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};
