import React, { useState } from 'react';
import { performBitStuffing, performBitDestuffing, countFlagOccurrences } from '../utils/bitStuffing';
import { StuffingResult, DestuffingResult } from '../types';
import { Play, RotateCcw, CheckCircle2, AlertCircle, Info, Sparkles, ArrowRight } from 'lucide-react';

interface ManualSimulatorProps {
  onExportResult?: (stuffing: StuffingResult, destuffing: DestuffingResult) => void;
}

export const ManualSimulator: React.FC<ManualSimulatorProps> = ({ onExportResult }) => {
  // Default to the prompt's canonical example
  const [inputBits, setInputBits] = useState<string>('1111101111110');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [stuffingResult, setStuffingResult] = useState<StuffingResult | null>(null);
  const [destuffingResult, setDestuffingResult] = useState<DestuffingResult | null>(null);

  // Preset examples for quick testing
  const presets = [
    { label: 'Prompt Example', value: '1111101111110', note: 'Two 5-ones clusters' },
    { label: 'Flag Inside Data (01111110)', value: '0111111010101111110', note: 'Contains raw HDLC flags' },
    { label: 'Ten Consecutive Ones', value: '1111111111', note: 'Stress test: 10 ones' },
    { label: 'No Stuffing Needed', value: '0101010100110011', note: 'No 5 ones in sequence' },
  ];

  // Auto-run simulation on initial load so students see results immediately
  React.useEffect(() => {
    const st = performBitStuffing(inputBits);
    if (st.isValid) {
      setStuffingResult(st);
      const dst = performBitDestuffing(st.stuffedBits, st.originalBits);
      if (dst.isValid) {
        setDestuffingResult(dst);
        if (onExportResult) {
          onExportResult(st, dst);
        }
      }
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const val = e.target.value;
    setInputBits(val);
    setErrorMessage(null);
  };

  const handleStuff = () => {
    setErrorMessage(null);
    setDestuffingResult(null);

    const result = performBitStuffing(inputBits);
    if (!result.isValid) {
      setErrorMessage(result.errorMessage || 'Invalid binary input.');
      setStuffingResult(null);
      return;
    }

    setStuffingResult(result);
  };

  const handleDestuff = () => {
    if (!stuffingResult) return;
    setErrorMessage(null);

    const destuff = performBitDestuffing(stuffingResult.stuffedBits, stuffingResult.originalBits);
    if (!destuff.isValid) {
      setErrorMessage(destuff.errorMessage || 'Destuffing failed.');
      return;
    }

    setDestuffingResult(destuff);
    if (onExportResult) {
      onExportResult(stuffingResult, destuff);
    }
  };

  const handleReset = () => {
    setInputBits('');
    setStuffingResult(null);
    setDestuffingResult(null);
    setErrorMessage(null);
  };

  const loadPreset = (val: string) => {
    setInputBits(val);
    setStuffingResult(null);
    setDestuffingResult(null);
    setErrorMessage(null);
  };

  return (
    <div className="space-y-6">
      {/* Simulation Workspace Card */}
      <div className="bg-white rounded-lg border border-blue-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-800">
              1. Bit Stuffing Simulator
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Enter binary data to simulate sender-side bit stuffing (inserting 0 after five consecutive 1s) and receiver-side destuffing.
            </p>
          </div>
          <div className="flex items-center gap-1.5 self-start sm:self-auto">
            <span className="text-xs text-slate-500 font-medium">Standard Rule:</span>
            <span className="text-xs bg-blue-50 text-blue-700 font-mono font-bold px-2 py-0.5 rounded border border-blue-200">
              5 Consecutive 1s &rarr; Insert 0
            </span>
          </div>
        </div>

        {/* Preset quick buttons */}
        <div className="mt-4">
          <div className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            <span>Select a Preset or Type Custom Binary Data:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {presets.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => loadPreset(p.value)}
                className={`text-xs px-2.5 py-1.5 rounded border transition-colors ${
                  inputBits === p.value
                    ? 'bg-blue-600 text-white border-blue-600 font-medium'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300'
                }`}
                title={p.note}
              >
                {p.label} <span className="opacity-75 font-mono text-[10px]">({p.value.slice(0, 8)}...)</span>
              </button>
            ))}
          </div>
        </div>

        {/* Input Field */}
        <div className="mt-4">
          <label htmlFor="binary-input" className="block text-xs font-semibold text-slate-700 mb-1.5">
            Binary Input Sequence (0 and 1 only):
          </label>
          <div className="relative">
            <input
              id="binary-input"
              type="text"
              value={inputBits}
              onChange={handleInputChange}
              placeholder="e.g. 1111101111110"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-md font-mono text-sm sm:text-base text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 tracking-wider"
            />
            {inputBits && (
              <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-mono">
                {inputBits.replace(/\s+/g, '').length} bits
              </span>
            )}
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="mt-2.5 p-3 bg-red-50 border border-red-200 rounded text-xs text-red-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            onClick={handleStuff}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs sm:text-sm font-semibold rounded-md shadow-xs transition-colors cursor-pointer"
          >
            <Play className="w-4 h-4" />
            <span>Stuff Bits</span>
          </button>

          <button
            onClick={handleDestuff}
            disabled={!stuffingResult}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-md shadow-xs transition-colors cursor-pointer ${
              stuffingResult
                ? 'bg-slate-800 hover:bg-slate-900 text-white'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>Destuff Bits</span>
          </button>

          <button
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs sm:text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors"
          >
            <span>Clear / Reset</span>
          </button>
        </div>
      </div>

      {/* Results View */}
      {stuffingResult && (
        <div className="space-y-5">
          {/* Visual Bit Stream Display */}
          <div className="bg-white rounded-lg border border-slate-200 p-5 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center justify-between">
              <span>Step-by-Step Bitstream Comparison</span>
              <span className="text-xs font-normal normal-case text-slate-500">
                Inserted 0 bits are highlighted with a blue tag
              </span>
            </h3>

            {/* 1. Original Binary Data */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-md">
              <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1.5">
                <span>1. Original Binary Data (Transmitter Input):</span>
                <span className="font-mono text-slate-700">{stuffingResult.originalLength} bits</span>
              </div>
              <div className="font-mono text-sm sm:text-base text-slate-800 tracking-widest break-all bg-white p-2.5 rounded border border-slate-200">
                {stuffingResult.originalBits}
              </div>
            </div>

            {/* 2. Stuffed Binary Data with Highlighting */}
            <div className="p-3.5 bg-blue-50/50 border border-blue-200 rounded-md">
              <div className="flex items-center justify-between text-xs text-blue-900 font-semibold mb-1.5">
                <span className="flex items-center gap-1.5">
                  <span>2. Stuffed Binary Data (Transmitted Frame Payload):</span>
                  <span className="bg-blue-600 text-white text-[10px] px-1.5 py-0.2 rounded font-bold">
                    +{stuffingResult.insertedCount} Stuffed
                  </span>
                </span>
                <span className="font-mono text-blue-900">{stuffingResult.stuffedLength} bits</span>
              </div>

              {/* Render bits with highlighting on stuffed indices */}
              <div className="font-mono text-sm sm:text-base tracking-widest break-all bg-white p-2.5 rounded border border-blue-200 flex flex-wrap items-center gap-y-1">
                {Array.from(stuffingResult.stuffedBits).map((bit, idx) => {
                  const isStuffed = stuffingResult.stuffedIndices.includes(idx);
                  if (isStuffed) {
                    return (
                      <span
                        key={idx}
                        className="inline-flex items-center justify-center bg-blue-600 text-white font-bold px-1.5 py-0.5 rounded mx-0.5 text-xs shadow-xs"
                        title={`Stuffed bit (0) inserted after five 1s at bit index ${idx}`}
                      >
                        {bit}
                        <span className="text-[9px] uppercase ml-0.5 tracking-tighter opacity-80">(stuffed)</span>
                      </span>
                    );
                  }
                  return (
                    <span key={idx} className="text-slate-800">
                      {bit}
                    </span>
                  );
                })}
              </div>

              <div className="mt-2 text-xs text-slate-600 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                <span>
                  {stuffingResult.insertedCount === 0
                    ? 'No sequence of five consecutive 1s occurred, so no 0 bits were stuffed.'
                    : `Inserted ${stuffingResult.insertedCount} zero-bit(s) immediately following every sequence of five 1s.`}
                </span>
              </div>
            </div>

            {/* 3. Recovered Data (Receiver Output) */}
            {destuffingResult ? (
              <div className="p-3.5 bg-emerald-50/70 border border-emerald-300 rounded-md">
                <div className="flex items-center justify-between text-xs text-emerald-900 font-semibold mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>3. Recovered Binary Data (Receiver Destuffed Output):</span>
                  </span>
                  <span className="font-mono text-emerald-900">{destuffingResult.recoveredBits.length} bits</span>
                </div>
                <div className="font-mono text-sm sm:text-base text-slate-800 tracking-widest break-all bg-white p-2.5 rounded border border-emerald-300">
                  {destuffingResult.recoveredBits}
                </div>
                <div className="mt-2 text-xs font-semibold text-emerald-800 flex items-center gap-1.5">
                  <span>Verification:</span>
                  {destuffingResult.isMatch ? (
                    <span className="text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                      SUCCESS &mdash; Recovered data matches original data exactly (100% Match)
                    </span>
                  ) : (
                    <span className="text-red-700 bg-red-100 px-2 py-0.5 rounded">
                      MISMATCH &mdash; Recovered data does not match original data.
                    </span>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-3 bg-slate-50 border border-dashed border-slate-300 rounded text-center text-xs text-slate-500">
                Click <strong>&quot;Destuff Bits&quot;</strong> to simulate the receiver side and recover the original data.
              </div>
            )}
          </div>

          {/* Mathematical Results & Overhead Calculation Box */}
          <div className="bg-white rounded-lg border border-slate-200 p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-800 mb-3">
              Transmission Overhead &amp; Calculation Metrics
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <div className="text-xs text-slate-500">Original Bits</div>
                <div className="text-lg font-bold text-slate-800 font-mono mt-1">
                  {stuffingResult.originalLength}
                </div>
              </div>

              <div className="p-3 bg-blue-50/60 border border-blue-200 rounded-md">
                <div className="text-xs text-blue-700">Stuffed Bits</div>
                <div className="text-lg font-bold text-blue-700 font-mono mt-1">
                  {stuffingResult.stuffedLength}
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <div className="text-xs text-slate-500">Inserted 0 Bits</div>
                <div className="text-lg font-bold text-blue-600 font-mono mt-1">
                  +{stuffingResult.insertedCount}
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <div className="text-xs text-slate-500">Overhead (%)</div>
                <div className="text-lg font-bold text-slate-800 font-mono mt-1">
                  {stuffingResult.overheadPercentage}%
                </div>
              </div>
            </div>

            {/* Formula Breakdown */}
            <div className="mt-4 p-3 bg-slate-50 rounded border border-slate-200 text-xs text-slate-600 font-mono space-y-1">
              <div className="font-semibold text-slate-700 font-sans">Formula Applied:</div>
              <div>Overhead (%) = (Number of Inserted Bits / Original Bits) &times; 100</div>
              <div className="text-blue-700 font-bold">
                = ({stuffingResult.insertedCount} / {stuffingResult.originalLength}) &times; 100 ={' '}
                {stuffingResult.overheadPercentage}%
              </div>
            </div>

            {/* Flag Collision Test */}
            <div className="mt-3 p-3 bg-blue-50/70 rounded border border-blue-200 text-xs text-blue-900 flex items-start gap-2">
              <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <strong>Frame Delimiter Check:</strong> In the original bitstream, the pattern{' '}
                <code className="font-mono font-bold bg-white px-1 py-0.5 rounded border border-blue-200">01111110</code>{' '}
                occurred {countFlagOccurrences(stuffingResult.originalBits)} time(s). In the stuffed bitstream, it occurs{' '}
                <strong>{countFlagOccurrences(stuffingResult.stuffedBits)} times</strong>. Because of bit stuffing, accidental frame delimiter collisions are completely eliminated!
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
