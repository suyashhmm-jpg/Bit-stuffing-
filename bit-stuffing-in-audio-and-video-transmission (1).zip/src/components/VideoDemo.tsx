import React, { useState, useRef } from 'react';
import { performBitStuffing, performBitDestuffing, arrayBufferToBinary, countFlagOccurrences } from '../utils/bitStuffing';
import { createSampleVideoBlob } from '../utils/mediaGenerators';
import { MediaProcessResult } from '../types';
import { Video, Upload, Play, Pause, CheckCircle2, AlertCircle, Info, Film, Sparkles } from 'lucide-react';

interface VideoDemoProps {
  onExportResult?: (result: MediaProcessResult) => void;
}

export const VideoDemo: React.FC<VideoDemoProps> = ({ onExportResult }) => {
  const [selectedFile, setSelectedFile] = useState<File | Blob | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [byteLimit, setByteLimit] = useState<number>(64);
  const [processResult, setProcessResult] = useState<MediaProcessResult | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Auto-load sample video on mount for instant demonstration
  React.useEffect(() => {
    let isCancelled = false;
    createSampleVideoBlob()
      .then((blob) => {
        if (!isCancelled) {
          const file = new File([blob], 'sample_pbl_video.webm', { type: 'video/webm' });
          processVideoFile(file, 'Sample Video (Generated WebM Stream Pattern)');
        }
      })
      .catch(() => {
        // ignore
      });
    return () => {
      isCancelled = true;
    };
  }, []);

  const handleLoadSample = async () => {
    try {
      setIsProcessing(true);
      setErrorMsg(null);
      const blob = await createSampleVideoBlob();
      const file = new File([blob], 'sample_pbl_video.webm', { type: 'video/webm' });
      processVideoFile(file, 'Sample Video (Generated WebM Stream Pattern)');
    } catch (err) {
      setErrorMsg('Failed to synthesize sample video in browser.');
      setIsProcessing(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('video/') && !file.name.match(/\.(mp4|webm|mov|mkv|avi)$/i)) {
      setErrorMsg('Please select a valid video file (.mp4, .webm, .mov, etc.).');
      return;
    }

    processVideoFile(file, file.name);
  };

  const processVideoFile = (file: File | Blob, displayName: string) => {
    setErrorMsg(null);
    setIsProcessing(true);

    if (videoUrl) {
      URL.revokeObjectURL(videoUrl);
    }

    const url = URL.createObjectURL(file);
    setVideoUrl(url);
    setSelectedFile(file);

    // Read initial manageable slice of video container bytes
    const slice = file.slice(0, byteLimit);
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        if (!buffer || buffer.byteLength === 0) {
          setErrorMsg('Video file could not be read or is empty.');
          setIsProcessing(false);
          return;
        }

        const { binary, hexPreview } = arrayBufferToBinary(buffer);
        const stuffing = performBitStuffing(binary);
        const destuffing = performBitDestuffing(stuffing.stuffedBits, binary);

        const flagsInOriginal = countFlagOccurrences(binary);
        const flagsInStuffed = countFlagOccurrences(stuffing.stuffedBits);

        const result: MediaProcessResult = {
          fileName: displayName,
          fileSizeBytes: file.size,
          fileType: file.type || 'video/unknown',
          processedBytesCount: buffer.byteLength,
          hexPreview,
          stuffing,
          destuffing,
          flagCheck: {
            flagsInOriginal,
            flagsInStuffed,
          },
        };

        setProcessResult(result);
        if (onExportResult) {
          onExportResult(result);
        }
      } catch (err) {
        setErrorMsg('Error processing video binary data.');
      } finally {
        setIsProcessing(false);
      }
    };

    reader.onerror = () => {
      setErrorMsg('Browser failed to read video file.');
      setIsProcessing(false);
    };

    reader.readAsArrayBuffer(slice);
  };

  const reprocessWithLimit = (newLimit: number) => {
    setByteLimit(newLimit);
    if (selectedFile) {
      processVideoFile(selectedFile, processResult?.fileName || 'Video');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info Box */}
      <div className="bg-white rounded-lg border border-blue-200 p-5 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg shrink-0">
            <Video className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-800">
              3. Video Demonstration
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Upload a video file or test the generated pattern video. The browser reads a portion of the video bytes, converts them to binary, applies bit stuffing (inserting 0 after every five consecutive 1s), and performs bit destuffing.
            </p>
          </div>
        </div>

        {/* Mandatory Educational Note */}
        <div className="mt-4 p-3 bg-blue-50/70 border border-blue-200 rounded-md text-xs text-blue-900 flex items-start gap-2">
          <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <p>
            <strong>PBL Note:</strong> This application demonstrates bit stuffing on video-file data at the binary framing level. It does not perform actual network transmission over physical media. The video is displayed and played locally in your browser.
          </p>
        </div>

        {/* Upload & Sample Video Controls */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                Option A: Upload Video File
              </div>
              <p className="text-xs text-slate-500 mb-3">
                Select an .mp4 or .webm video file from your computer.
              </p>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="video/*,.mp4,.webm,.mov"
              onChange={handleFileUpload}
              className="hidden"
              id="video-file-input"
            />
            <label
              htmlFor="video-file-input"
              className="inline-flex items-center justify-center gap-2 px-3 py-2 bg-white border border-slate-300 hover:border-blue-400 text-slate-700 hover:text-blue-700 rounded-md text-xs font-semibold shadow-xs cursor-pointer transition-colors"
            >
              <Upload className="w-4 h-4" />
              <span>Choose Video File</span>
            </label>
          </div>

          <div className="p-4 bg-blue-50/50 border border-blue-200 rounded-lg flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-blue-900 uppercase tracking-wide mb-1">
                Option B: Quick Sample Video
              </div>
              <p className="text-xs text-slate-500 mb-3">
                Generate a live test pattern animation WebM video in the browser.
              </p>
            </div>

            <button
              onClick={handleLoadSample}
              disabled={isProcessing}
              className="inline-flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-semibold shadow-xs cursor-pointer transition-colors disabled:opacity-60"
            >
              <Film className="w-4 h-4" />
              <span>{isProcessing ? 'Generating WebM...' : 'Generate Sample Video'}</span>
            </button>
          </div>
        </div>

        {/* Chunk Limit Selector */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 text-xs">
          <span className="text-slate-600 font-medium">
            Manageable slice size to convert and bit-stuff (first N bytes):
          </span>
          <div className="flex items-center gap-1.5">
            {[32, 64, 128, 256].map((size) => (
              <button
                key={size}
                type="button"
                onClick={() => reprocessWithLimit(size)}
                className={`px-2.5 py-1 rounded border text-xs font-mono font-medium transition-colors ${
                  byteLimit === size
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                {size} bytes ({size * 8} bits)
              </button>
            ))}
          </div>
        </div>

        {errorMsg && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Video Player & Results */}
      {selectedFile && videoUrl && processResult && (
        <div className="space-y-5">
          {/* Video Player Card */}
          <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-xs">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="w-full md:w-80 bg-black rounded overflow-hidden aspect-video relative flex items-center justify-center">
                <video
                  ref={videoRef}
                  src={videoUrl}
                  controls
                  playsInline
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="grow space-y-2 text-xs">
                <div className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Film className="w-4 h-4 text-blue-600" />
                  <span>{processResult.fileName}</span>
                </div>
                <div className="text-slate-500">
                  Container Format: <span className="font-mono text-slate-700">{processResult.fileType}</span> &bull; File Size:{' '}
                  <span className="font-mono text-slate-700">{(processResult.fileSizeBytes / 1024).toFixed(1)} KB</span>
                </div>
                <div className="text-slate-500">
                  Processed Stream Portion:{' '}
                  <strong className="text-blue-700">{processResult.processedBytesCount} bytes</strong> ({processResult.stuffing.originalLength} bits)
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200 text-slate-600">
                  Video players decode streams frame-by-frame. In real networks, video bitstreams are segmented into transport packets with frame boundary flags. Bit stuffing prevents corruption of intra-frame (I-frame) headers!
                </div>
              </div>
            </div>
          </div>

          {/* Results Display */}
          <div className="bg-white rounded-lg border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
                Video Bitstream Analysis &amp; Stuffing
              </h3>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Original Recovered: 100% Match
              </span>
            </div>

            {/* Hex preview */}
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <div className="text-xs font-semibold text-slate-600 mb-1">
                Video Raw Byte Stream (Hexadecimal Preview - first {processResult.hexPreview.length} bytes):
              </div>
              <div className="font-mono text-xs text-slate-700 break-all tracking-wider">
                {processResult.hexPreview.join(' ')}
              </div>
            </div>

            {/* Original vs Stuffed bitstream summary */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Original Bits */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-700 mb-1.5">
                  <span>Original Video Bitstream</span>
                  <span className="font-mono text-slate-600">{processResult.stuffing.originalLength} bits</span>
                </div>
                <div className="font-mono text-xs text-slate-800 break-all bg-white p-2.5 rounded border border-slate-200 max-h-40 overflow-y-auto leading-relaxed">
                  {processResult.stuffing.originalBits}
                </div>
              </div>

              {/* Stuffed Bits */}
              <div className="p-3 bg-blue-50/50 border border-blue-200 rounded-md">
                <div className="flex justify-between items-center text-xs font-semibold text-blue-900 mb-1.5">
                  <span className="flex items-center gap-1">
                    <span>Stuffed Video Bitstream</span>
                    <span className="bg-blue-600 text-white text-[10px] px-1 rounded">
                      +{processResult.stuffing.insertedCount} 0s
                    </span>
                  </span>
                  <span className="font-mono text-blue-900">{processResult.stuffing.stuffedLength} bits</span>
                </div>
                <div className="font-mono text-xs tracking-normal break-all bg-white p-2.5 rounded border border-blue-200 max-h-40 overflow-y-auto leading-relaxed">
                  {Array.from(processResult.stuffing.stuffedBits).map((bit, idx) => {
                    const isStuffed = processResult.stuffing.stuffedIndices.includes(idx);
                    if (isStuffed) {
                      return (
                        <span
                          key={idx}
                          className="bg-blue-600 text-white font-bold px-1 rounded mx-0.5 text-[11px]"
                          title={`Stuffed 0 at bit index ${idx}`}
                        >
                          {bit}
                        </span>
                      );
                    }
                    return <span key={idx} className="text-slate-800">{bit}</span>;
                  })}
                </div>
              </div>
            </div>

            {/* Metrics Breakdown Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center pt-2">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="text-xs text-slate-500">Original Bits</div>
                <div className="text-base font-bold text-slate-800 font-mono mt-0.5">
                  {processResult.stuffing.originalLength}
                </div>
              </div>
              <div className="p-3 bg-blue-50/60 border border-blue-200 rounded">
                <div className="text-xs text-blue-700">Stuffed Bits</div>
                <div className="text-base font-bold text-blue-700 font-mono mt-0.5">
                  {processResult.stuffing.stuffedLength}
                </div>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="text-xs text-slate-500">Inserted 0 Bits</div>
                <div className="text-base font-bold text-blue-600 font-mono mt-0.5">
                  +{processResult.stuffing.insertedCount}
                </div>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <div className="text-xs text-slate-500">Overhead (%)</div>
                <div className="text-base font-bold text-slate-800 font-mono mt-0.5">
                  {processResult.stuffing.overheadPercentage}%
                </div>
              </div>
            </div>

            {/* Destuffing verification banner */}
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded text-xs text-emerald-900 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>Destuffing Verification:</strong> Successfully removed all {processResult.stuffing.insertedCount} stuffed 0 bits.
                  Original video bitstream is recovered with 100% precision.
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
