import React from 'react';
import { BookOpen, ShieldCheck, Flag, ArrowRight, HelpCircle, Music, Video, Zap } from 'lucide-react';

interface LearnSectionProps {
  onGoToSimulator: () => void;
}

export const LearnSection: React.FC<LearnSectionProps> = ({ onGoToSimulator }) => {
  return (
    <div className="space-y-6">
      {/* Intro Hero Card */}
      <div className="bg-white rounded-lg border border-blue-200 p-5 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg shrink-0">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">
              Understanding Bit Stuffing in Data Communication
            </h2>
            <p className="text-sm text-slate-600 mt-1 leading-relaxed">
              In computer networks and telecommunications (Data Link Layer), messages are divided into smaller packets called <strong>frames</strong>. 
              To help the receiver know where a frame begins and ends, special marker sequences called <strong>Flags (Frame Delimiters)</strong> are added. 
              <strong>Bit stuffing</strong> is the technique that ensures the receiver never mistakes the contents of your audio or video file for a frame marker.
            </p>
          </div>
        </div>
      </div>

      {/* Grid of the 5 Core Questions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Question 1: What is bit stuffing? */}
        <div className="bg-white rounded-lg border border-slate-200 hover:border-blue-300 transition-colors p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-xs font-bold text-blue-700">1</span>
              <span>What is Bit Stuffing?</span>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              <strong>Bit stuffing</strong> is a bit-level framing mechanism where a transmitter inserts non-information bits (specifically a single <code className="bg-slate-100 text-blue-800 px-1 py-0.5 rounded font-mono font-bold">0</code> bit) into a data stream according to a predetermined rule before sending it across the physical medium.
            </p>
            <div className="mt-3 p-3 bg-blue-50/70 border border-blue-100 rounded text-xs text-slate-700">
              <strong>The Golden Rule:</strong> Whenever the transmitter detects <strong>five consecutive 1s (<code className="font-mono text-blue-700 font-bold">11111</code>)</strong> in the user data, it forcibly injects an extra <code className="font-mono text-blue-700 font-bold">0</code> right after them.
            </div>
          </div>
        </div>

        {/* Question 2: Why is bit stuffing required? */}
        <div className="bg-white rounded-lg border border-slate-200 hover:border-blue-300 transition-colors p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-xs font-bold text-blue-700">2</span>
              <span>Why is Bit Stuffing Required?</span>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              Data sent over networks must be <strong>transparent</strong>. This means the sender should be able to transmit <em>any arbitrary combination of binary bits</em> without the network confusing payload bits with synchronization commands.
            </p>
            <div className="mt-3 p-3 bg-amber-50/80 border border-amber-200 rounded text-xs text-amber-900">
              <strong>The Danger:</strong> If user data accidentally contains the exact sequence used as a frame boundary, the receiver would terminate the frame prematurely, drop the rest of the message, and corrupt the audio or video!
            </div>
          </div>
        </div>

        {/* Question 3: What is a flag or frame delimiter? */}
        <div className="bg-white rounded-lg border border-slate-200 hover:border-blue-300 transition-colors p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-xs font-bold text-blue-700">3</span>
              <span>What is a Flag or Frame Delimiter?</span>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              A <strong>Flag</strong> is a fixed 8-bit special pattern defined by data link protocols such as HDLC (High-Level Data Link Control) and SDLC:
            </p>
            <div className="mt-2 text-center py-2 bg-slate-100 rounded border border-slate-300 font-mono text-sm tracking-widest text-slate-800">
              <span className="text-blue-600 font-bold">0</span>
              <span className="text-emerald-700 font-bold">111111</span>
              <span className="text-blue-600 font-bold">0</span>
              <span className="text-xs text-slate-500 font-sans tracking-normal ml-2">(Six consecutive 1s surrounded by 0s)</span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Every frame starts with this flag and ends with this flag. By stuffing a 0 after five 1s, the sequence <code className="font-mono text-slate-800 font-semibold">01111110</code> can <strong>never</strong> accidentally occur inside the payload!
            </p>
          </div>
        </div>

        {/* Question 4: How does bit stuffing work? */}
        <div className="bg-white rounded-lg border border-slate-200 hover:border-blue-300 transition-colors p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-xs font-bold text-blue-700">4</span>
              <span>How Does It Work Step-by-Step?</span>
            </div>
            <ul className="text-xs text-slate-600 space-y-2">
              <li className="flex items-start gap-1.5">
                <span className="text-blue-600 font-bold">&bull;</span>
                <span><strong>At Transmitter (Stuffing):</strong> Scans the bitstream. Counts consecutive 1s. When 5 ones appear (<code className="font-mono bg-slate-100 text-blue-700 px-1 py-0.2">11111</code>), immediately insert a <code className="font-mono bg-blue-100 text-blue-800 px-1 py-0.2 font-bold">0</code>, even if the next original bit was already 0.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-blue-600 font-bold">&bull;</span>
                <span><strong>In Transmission:</strong> Receiver listens for bit stream. Payload never contains six consecutive 1s.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-blue-600 font-bold">&bull;</span>
                <span><strong>At Receiver (Destuffing):</strong> Counts consecutive 1s. Whenever 5 ones appear, it examines the 6th bit. If it is 0, the receiver drops it (destuffs) to restore the original data!</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Question 5: How is it useful in Audio and Video Transmission? */}
      <div className="bg-white rounded-lg border border-blue-200 p-5 shadow-xs">
        <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-3">
          <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-xs font-bold text-blue-700">5</span>
          <span className="text-base text-slate-800 font-bold">How is Bit Stuffing Useful in Audio and Video Transmission?</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm text-slate-600">
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center gap-2 text-slate-800 font-semibold">
              <Music className="w-4 h-4 text-blue-600" />
              <span>Audio Data Streams (WAV, MP3, AAC)</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Audio data consists of continuous pulse-code modulation (PCM) audio samples or compressed psychoacoustic bitrates. Arbitrary audio samples frequently form the exact bit sequence <code className="font-mono bg-slate-200 px-1 text-slate-800">01111110</code>. Without bit stuffing, an audio stream would experience premature frame cuts, lost audio packets, and audible cracking/popping artifacts.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center gap-2 text-slate-800 font-semibold">
              <Video className="w-4 h-4 text-blue-600" />
              <span>Video Data Streams (MP4, H.264, WebM)</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              High-definition video files carry millions of high-entropy compressed binary bits (Huffman codes, transform coefficients). A false delimiter would cause catastrophic frame desynchronization, resulting in green screen distortion, frozen frames, or tearing. Bit stuffing provides complete data transparency so any video file transfers safely.
            </p>
          </div>
        </div>

        {/* Visual Frame Structure Diagram */}
        <div className="mt-5 p-4 bg-blue-50/70 border border-blue-200 rounded-lg">
          <div className="text-xs font-semibold text-blue-800 uppercase tracking-wide mb-2">
            HDLC / Data Link Frame Architecture
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 text-center text-xs font-mono font-medium">
            <div className="bg-blue-600 text-white p-2.5 rounded shadow-xs sm:w-36">
              <div className="text-[10px] uppercase font-sans text-blue-200">Starting Flag</div>
              <div className="font-bold text-sm">01111110</div>
            </div>
            <div className="text-slate-400 font-sans hidden sm:block">+</div>
            <div className="bg-white border-2 border-dashed border-blue-400 text-slate-800 p-2.5 rounded grow">
              <div className="text-[10px] uppercase font-sans text-blue-600 font-bold">Bit-Stuffed Audio / Video Payload</div>
              <div className="text-xs text-slate-600 font-mono mt-0.5">
                ... 11111<span className="text-blue-600 font-bold bg-blue-100 px-1 rounded">0</span> ... 11111<span className="text-blue-600 font-bold bg-blue-100 px-1 rounded">0</span> ... (Zero Occurrences of 01111110)
              </div>
            </div>
            <div className="text-slate-400 font-sans hidden sm:block">+</div>
            <div className="bg-blue-600 text-white p-2.5 rounded shadow-xs sm:w-36">
              <div className="text-[10px] uppercase font-sans text-blue-200">Ending Flag</div>
              <div className="font-bold text-sm">01111110</div>
            </div>
          </div>
        </div>

        {/* Call to action */}
        <div className="mt-4 flex justify-end">
          <button
            onClick={onGoToSimulator}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-medium rounded-md transition-colors shadow-xs"
          >
            <span>Proceed to Manual Bit Simulator</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
