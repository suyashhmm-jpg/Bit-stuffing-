import React from 'react';
import { StuffingResult, DestuffingResult, MediaProcessResult } from '../types';
import { BarChart3, CheckCircle2, AlertCircle, Info, Calculator, Award } from 'lucide-react';

interface ResultsSummaryProps {
  manualRun?: { stuffing: StuffingResult; destuffing: DestuffingResult | null } | null;
  audioRun?: MediaProcessResult | null;
  videoRun?: MediaProcessResult | null;
  onNavigateTab: (tabId: string) => void;
}

export const ResultsSummary: React.FC<ResultsSummaryProps> = ({
  manualRun,
  audioRun,
  videoRun,
  onNavigateTab,
}) => {
  const runs = [
    {
      name: 'Manual Binary Test',
      source: manualRun ? 'User Input' : 'Not executed yet',
      originalBits: manualRun?.stuffing.originalLength ?? null,
      stuffedBits: manualRun?.stuffing.stuffedLength ?? null,
      insertedBits: manualRun?.stuffing.insertedCount ?? null,
      overhead: manualRun?.stuffing.overheadPercentage ?? null,
      recovered: manualRun?.destuffing ? manualRun.destuffing.isMatch : null,
      tabId: 'simulator',
    },
    {
      name: 'Audio Transmission Demo',
      source: audioRun ? audioRun.fileName : 'Not executed yet',
      originalBits: audioRun?.stuffing.originalLength ?? null,
      stuffedBits: audioRun?.stuffing.stuffedLength ?? null,
      insertedBits: audioRun?.stuffing.insertedCount ?? null,
      overhead: audioRun?.stuffing.overheadPercentage ?? null,
      recovered: audioRun ? audioRun.destuffing.isMatch : null,
      tabId: 'audio-demo',
    },
    {
      name: 'Video Transmission Demo',
      source: videoRun ? videoRun.fileName : 'Not executed yet',
      originalBits: videoRun?.stuffing.originalLength ?? null,
      stuffedBits: videoRun?.stuffing.stuffedLength ?? null,
      insertedBits: videoRun?.stuffing.insertedCount ?? null,
      overhead: videoRun?.stuffing.overheadPercentage ?? null,
      recovered: videoRun ? videoRun.destuffing.isMatch : null,
      tabId: 'video-demo',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="bg-white rounded-lg border border-blue-200 p-5 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg shrink-0">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-800">
              4. Results &amp; Summary
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Consolidated real-time metrics showing original bit counts, stuffed bit counts, inserted zero bits, transmission overhead percentage, and bit-level recovery status across all experiments.
            </p>
          </div>
        </div>
      </div>

      {/* Main Results Table */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-xs">
        <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            Consolidated Experimental Results
          </span>
          <span className="text-xs text-slate-500">
            Overhead Formula: <code className="font-mono font-bold text-blue-700">(Inserted / Original) &times; 100</code>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="bg-slate-100/75 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="p-3 pl-5">Experiment / Domain</th>
                <th className="p-3">Data Source / File</th>
                <th className="p-3 text-right">Original Bits</th>
                <th className="p-3 text-right">Stuffed Bits</th>
                <th className="p-3 text-right">Inserted 0 Bits</th>
                <th className="p-3 text-right">Overhead (%)</th>
                <th className="p-3 text-center pr-5">Recovery Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {runs.map((r, idx) => {
                const hasRun = r.originalBits !== null;
                return (
                  <tr key={idx} className="hover:bg-blue-50/30 transition-colors">
                    <td className="p-3 pl-5 font-medium text-slate-800">
                      <div>{r.name}</div>
                    </td>
                    <td className="p-3 text-slate-500 max-w-xs truncate">
                      {hasRun ? (
                        <span className="font-mono text-slate-700">{r.source}</span>
                      ) : (
                        <button
                          onClick={() => onNavigateTab(r.tabId)}
                          className="text-blue-600 hover:underline cursor-pointer"
                        >
                          Click to execute &rarr;
                        </button>
                      )}
                    </td>
                    <td className="p-3 text-right font-mono text-slate-800">
                      {hasRun ? r.originalBits : '&mdash;'}
                    </td>
                    <td className="p-3 text-right font-mono text-blue-700 font-semibold">
                      {hasRun ? r.stuffedBits : '&mdash;'}
                    </td>
                    <td className="p-3 text-right font-mono text-slate-800">
                      {hasRun ? `+${r.insertedBits}` : '&mdash;'}
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-slate-800">
                      {hasRun ? `${r.overhead}%` : '&mdash;'}
                    </td>
                    <td className="p-3 pr-5 text-center">
                      {hasRun ? (
                        r.recovered ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>100% Match (Recovered)</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-800">
                            <AlertCircle className="w-3.5 h-3.5" />
                            <span>Mismatch</span>
                          </span>
                        )
                      ) : (
                        <span className="text-slate-400 text-xs italic">Pending</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Engineering Analysis & Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Overhead Analysis */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
            <Calculator className="w-4 h-4 text-blue-600" />
            <span>Overhead Trade-off Analysis</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            In typical random binary data, five consecutive 1s occur with a probability of approximately{' '}
            <code className="font-mono text-blue-700">(1/2)^5 = 1/32 (3.125%)</code>. In high-entropy audio and video streams, stuffing typically adds only <strong>1% to 3.5%</strong> overhead. This tiny transmission penalty is well worth the guarantee that frames are never cut short or dropped!
          </p>
        </div>

        {/* PBL Project Conclusions */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
            <Award className="w-4 h-4 text-blue-600" />
            <span>Key PBL Engineering Findings</span>
          </div>
          <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-4">
            <li><strong>Data Transparency:</strong> Any audio sample or video frame can be transmitted without restricting user data bytes.</li>
            <li><strong>Zero Boundary Ambiguity:</strong> The flag <code className="font-mono text-slate-800">01111110</code> never appears inside the payload.</li>
            <li><strong>Lossless Recovery:</strong> Bit destuffing restores 100% of the original audio and video bits with zero corruption.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
